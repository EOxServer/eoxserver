OpenGIS(r) SWE Service schema - ReadMe.txt
=========================================

OGC(r) Sensor Web Enablement (SWE) Service Model
-----------------------------------------------------------------------

Sensor Web Enablement (SWE) Service Model Implementation Standard.

The SWE Service 2.0 standard is defined in OGC document 09-001.

More information may be found at
 http://www.opengeospatial.org/standards/swes

The most current schema are available at http://schemas.opengis.net/ .

The root (all-components) XML Schema Document, which includes
directly and indirectly all the XML Schema Documents, defined by
SWE Service 2.0 is swes.xsd.

* Latest version is: http://schemas.opengis.net/swes/2.0/swes.xsd *

-----------------------------------------------------------------------


2011-03-18  Johannes Echterhoff

  * v2.0.0: Added swes/2.0 - OGC 09-001


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2011 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
