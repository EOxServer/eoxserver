OGC(r) GeoSPARQL schema - ReadMe.txt
========================================

OGC GeoSPARQL - A Geographic Query Language for RDF Data

More information may be found at
 http://www.opengeospatial.org/standards/geosparql

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------


2012-06-12  Kevin Stegemoller

  + v1.0.0: added geosparql/1.0 - OGC 11-052r4


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2012 Open Geospatial Consortium.

-----------------------------------------------------------------------
