OpenGIS(r) WMTS 1.0.0 - ReadMe.txt
======================================

-----------------------------------------------------------------------

Web Map Tile Service (WMTS) interface standard (OGC 07-057r7)

More information on the OGC WMTS standard may be found at
 http://www.opengeospatial.org/standards/wmts

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2010-05-04  Kevin Stegemoller 
 * v1.0: post wmts/1.0.0 as wmts/1.0 from OGC 07-057r7
 * v1.0: These documents were validated with:
   + XSV Validator version 3.1.1
   + Xerces-c validator version 2.8.0
   + libxml2 validator version 2.7.3
   + AltovaXML 2009
   + MSXML parser 4.0 sp2.
     -- Joan Maso

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2010 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
