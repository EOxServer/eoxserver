
OGC(r) XLink schema - ReadMe.txt
================================

OGC(r) XLink implementation of W3C XLink 1.0
-------------------------------------------------------------------

More information may be found at
 http://www.opengeospatial.org/standards/

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2012-07-21  Kevin Stegemoller
  * WARNING XLink change is NOT BACKWARD COMPATIBLE.
  * Changed OGC XLink (xlink:simpleLink) to W3C XLink (xlink:simpleAttrs)
    per an approved TC and PC motion during the Dec. 2011 Brussels meeting.
    See http://www.opengeospatial.org/blog/1597 
    See http://www.ogcnetwork.net/node/1829
  * v1.0: xlink/1.0.0/xlinks.xsd schema was removed and archived

2005-11-22  Arliss Whiteside
  * This XML Schema Document named xlinks.xsd has been stored here based 
    on the change request: 
      OGC 05-068r1 "Store xlinks.xsd file at a fixed location"

 Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2012 Open Geospatial Consortium.

-----------------------------------------------------------------------

