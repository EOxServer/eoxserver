OpenGIS(r) OWS Common 2.0 - ReadMe.txt
======================================

Web Service Common (OWS) Implementation Specification (OGC 06-121r9)

More information on the OGC OWS Common standard may be found at
 http://www.opengeospatial.org/standards/common

The most current schema are available at http://schemas.opengis.net/ .

The root (all-components) XML Schema Document, which includes
directly and indirectly all the XML Schema Documents, defined by
OWS 2.0 is owsAll.xsd .

-----------------------------------------------------------------------

2011-10-21  Jim Greenwood
 * v2.0.1: Incorporate OWS 2.0 Corrigendum 1 (OGC 11-157) to allow 
   multi-language use.

2010-05-06  Jim Greenwood
 * v2.0: post ows/2.0.0 as ows/2.0 from OGC 06-121r9

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2009-2011 Open Geospatial Consortium. All Rights Reserved.

-----------------------------------------------------------------------
