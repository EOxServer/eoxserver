OpenGIS(r) GML simple features profile - ReadMe.txt
==============================================================

OGC(r) Geography Markup Language (GML) simple features profile
-----------------------------------------------------------------------

The Geography Markup Language (GML) simple features 2.0 profile 
Implementation Standard is defined in OGC document 10-100r3.

More information may be found at
 http://www.opengeospatial.org/standards/gml

The most current schema are available at http://schemas.opengis.net/ 
and all OGC schemas may be downloaded in a complete bundle from 
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

The root (all-components) XML Schema Document, which includes
directly and indirectly all the XML Schema Documents, defined by
GML simple features 2.0 profile is gmlsfLevels.xsd.

* Latest version is: http://schemas.opengis.net/gmlsfProfile/2.0/gmlsfLevels.xsd *

-----------------------------------------------------------------------


2011-05-13  Clemens Portele

  * v2.0.0: Added gmlsfProfile/2.0 - OGC 10-100r3


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2011 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
