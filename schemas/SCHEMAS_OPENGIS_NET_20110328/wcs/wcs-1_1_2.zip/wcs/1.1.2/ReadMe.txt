OpenGIS(r) WCS schema version 1.1.2 - ReadMe.txt
-----------------------------------------------------------------------

The Web Coverage Service (WCS) Implementation Standard version 1.1.2 is
defined in the OGC document 07-067r5.  WCS 1.1.2 is amended in the OGC
Corrigendum document 07-066r5 .

More information on the OGC WCS standard may be found at
 http://www.opengeospatial.org/standards/wcs

-----------------------------------------------------------------------


Changes made to WCS 1.1.2:

-- 2008-05-28

-----------------------------------------------------------------------

The Open Geospatial Consortium, Inc. official schema repository is at
  http://schemas.opengis.net/ .
Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/policies/ .
Additional rights of use are described at
  http://www.opengeospatial.org/legal/ . 

Copyright (c) 2008 Open Geospatial Consortium, Inc. All Rights Reserved.

